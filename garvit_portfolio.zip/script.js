
// Client-side behavior: preview uploaded image, show form success, download embedded resume
document.addEventListener('DOMContentLoaded', function(){
  const imgInput = document.getElementById('image-upload');
  const profileImg = document.getElementById('profile-img');
  const form = document.getElementById('contact-form');
  const result = document.getElementById('form-result');
  const downloadBtn = document.getElementById('download-cv');

  imgInput.addEventListener('change', function(e){
    const f = e.target.files[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = function(ev){ profileImg.src = ev.target.result; }
    reader.readAsDataURL(f);
  });

  form.addEventListener('submit', function(e){
    e.preventDefault();
    const data = new FormData(form);
    // this demo does not send data to a server. Show a friendly message instead.
    result.textContent = "Thanks " + (data.get('name') || '') + "! Message recorded locally (no server).";
    form.reset();
  });

  downloadBtn.addEventListener('click', function(){
    // download embedded resume (garvit_resume.pdf included in zip)
    const link = document.createElement('a');
    link.href = 'garvit_resume.pdf';
    link.download = 'Garvit_Singhal_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    link.remove();
  });
});
