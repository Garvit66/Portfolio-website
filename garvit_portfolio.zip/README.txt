Garvit Singhal — Portfolio Website
Files:
- index.html, styles.css, script.js
- assets/profile.svg
- garvit_resume.pdf (resume)

How to use:
1. Unzip the archive and open index.html in a browser to view the site locally.
2. To deploy: upload files to GitHub Pages, Netlify, or any static host.

Notes:
- The 'Download Resume' button will download garvit_resume.pdf.
- The image upload field previews a profile picture on the page (client-side only).
